#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ParkourVaultComponent.generated.h"

UENUM(BlueprintType)
enum class EParkourActionType : uint8
{
    None        UMETA(DisplayName = "None"),
    Vault       UMETA(DisplayName = "Low Vault"),
    Mantle      UMETA(DisplayName = "High Ledge Mantle"),
    Slide       UMETA(DisplayName = "Power Slide"),
    WallRun     UMETA(DisplayName = "Wall Run")
};

USTRUCT(BlueprintType)
struct FParkourTraceHitResult
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly)
    bool bHitObstacle = false;

    UPROPERTY(BlueprintReadOnly)
    FVector ObstacleWallNormal = FVector::ZeroVector;

    UPROPERTY(BlueprintReadOnly)
    FVector ObstacleTopLedgeLocation = FVector::ZeroVector;

    UPROPERTY(BlueprintReadOnly)
    float ObstacleHeight = 0.0f;

    UPROPERTY(BlueprintReadOnly)
    float ObstacleDepth = 0.0f;
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UE5LOCOMOTIONPARKOUR_API UParkourVaultComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UParkourVaultComponent();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Parkour|Config")
    float ForwardTraceDistance = 150.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Parkour|Config")
    float MaxVaultHeight = 120.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Parkour|Config")
    float MaxMantleHeight = 220.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Parkour|Config")
    float MinObstacleHeight = 35.0f;

    UFUNCTION(BlueprintCallable, Category = "Parkour")
    bool EvaluateParkourObstacle(FParkourTraceHitResult& OutResult);

    UFUNCTION(BlueprintCallable, Category = "Parkour")
    bool ExecuteParkourAction(EParkourActionType ActionType, const FParkourTraceHitResult& TraceData);

protected:
    virtual void BeginPlay() override;
};
