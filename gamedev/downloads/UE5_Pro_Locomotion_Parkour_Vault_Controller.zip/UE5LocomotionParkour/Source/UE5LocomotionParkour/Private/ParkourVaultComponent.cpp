#include "ParkourVaultComponent.h"
#include "GameFramework/Character.h"
#include "DrawDebugHelpers.h"

UParkourVaultComponent::UParkourVaultComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
}

void UParkourVaultComponent::BeginPlay()
{
    Super::BeginPlay();
}

bool UParkourVaultComponent::EvaluateParkourObstacle(FParkourTraceHitResult& OutResult)
{
    ACharacter* OwnerChar = Cast<ACharacter>(GetOwner());
    if (!OwnerChar) return false;

    FVector StartLoc = OwnerChar->GetActorLocation();
    FVector ForwardDir = OwnerChar->GetActorForwardVector();
    FVector EndLoc = StartLoc + (ForwardDir * ForwardTraceDistance);

    FHitResult ForwardHit;
    FCollisionQueryParams Params;
    Params.AddIgnoredActor(OwnerChar);

    bool bHitWall = GetWorld()->LineTraceSingleByChannel(ForwardHit, StartLoc, EndLoc, ECC_Visibility, Params);
    if (!bHitWall) return false;

    OutResult.bHitObstacle = true;
    OutResult.ObstacleWallNormal = ForwardHit.ImpactNormal;

    // Downward sweep to find exact ledge height
    FVector DownStart = ForwardHit.Location + (ForwardDir * 15.0f) + FVector(0, 0, MaxMantleHeight);
    FVector DownEnd = ForwardHit.Location + (ForwardDir * 15.0f);

    FHitResult DownHit;
    if (GetWorld()->LineTraceSingleByChannel(DownHit, DownStart, DownEnd, ECC_Visibility, Params))
    {
        OutResult.ObstacleTopLedgeLocation = DownHit.ImpactPoint;
        OutResult.ObstacleHeight = DownHit.ImpactPoint.Z - (StartLoc.Z - OwnerChar->GetSimpleCollisionHalfHeight());
        return OutResult.ObstacleHeight >= MinObstacleHeight && OutResult.ObstacleHeight <= MaxMantleHeight;
    }

    return false;
}

bool UParkourVaultComponent::ExecuteParkourAction(EParkourActionType ActionType, const FParkourTraceHitResult& TraceData)
{
    // Execute warp motion or root motion montage trigger
    return true;
}
