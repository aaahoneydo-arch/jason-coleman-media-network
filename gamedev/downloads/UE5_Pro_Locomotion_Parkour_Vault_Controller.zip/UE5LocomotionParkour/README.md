# Unreal Engine 5 Pro Locomotion & Parkour Vaulting Controller

Production AAA fluid kinematic locomotion, procedural dual-ray obstacle scanning, dynamic hurdle vaulting, and ledge mantle system for Unreal Engine 5.3, 5.4, and 5.5.

## Key Architecture
- **Dual-Raycast Ledge Scanner**: Evaluates obstacle height, depth, and wall normal vector with sub-millimeter precision.
- **Motion Warping Ready**: Seamlessly bridges into UE5 Motion Warping and Animation Montages.
- **Modular ActorComponent**: Drop onto any `ACharacter` class with zero C++ boilerplate or engine modification.
