#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "QuestManagerComponent.generated.h"

UENUM(BlueprintType)
enum class EQuestStatus : uint8
{
    Unassigned   UMETA(DisplayName = "Unassigned"),
    Active       UMETA(DisplayName = "Active"),
    Completed    UMETA(DisplayName = "Completed"),
    Failed       UMETA(DisplayName = "Failed")
};

USTRUCT(BlueprintType)
struct FQuestObjectiveData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName ObjectiveID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText ObjectiveDescription;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 RequiredCount = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 CurrentCount = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bIsComplete = false;
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UE5QUESTGRAPH_API UQuestManagerComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UQuestManagerComponent();

    UFUNCTION(BlueprintCallable, Category = "Quests")
    bool StartQuest(FName QuestID);

    UFUNCTION(BlueprintCallable, Category = "Quests")
    void ProgressObjective(FName QuestID, FName ObjectiveID, int32 Amount = 1);

    UFUNCTION(BlueprintCallable, Category = "Quests")
    EQuestStatus GetQuestState(FName QuestID) const;
};
