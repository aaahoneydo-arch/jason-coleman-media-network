# Unreal Engine 5 Branching Quest & Objective State Graph

Production-grade quest state machine and branching objective engine for RPGs, extraction shooters, and immersive narrative sims in Unreal Engine 5.3, 5.4, and 5.5.

## Core Features
- **Prerequisite Validation**: Dynamic node conditions (level, faction rep, inventory items) before quest activation.
- **Serializes to SaveGame**: Fully integrated with UE5 `USaveGame` for instant checkpointing and save/load persistence.
- **UI Event Broadcasts**: Clean Blueprint Assignable multicast delegates for HUD objective notifications.
