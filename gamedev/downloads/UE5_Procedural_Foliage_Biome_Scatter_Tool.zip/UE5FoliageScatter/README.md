# Unreal Engine 5 Procedural Foliage & Biome Scatter Tool

Ultra-fast Poisson Disc sampling and altitude/slope masked vegetation scattering for open-world environments in Unreal Engine 5.3, 5.4, and 5.5.

## Highlights
- **Automatic HISM Clustering**: Employs Hierarchical Instanced Static Mesh components with Nanite & Lumen culling.
- **Slope & Height Rules**: Strict physical placement bounds prevent foliage on sheer cliffs or underwater.
- **Deterministic Seeding**: Fully reproducible terrain populator for multi-biome landscapes.
