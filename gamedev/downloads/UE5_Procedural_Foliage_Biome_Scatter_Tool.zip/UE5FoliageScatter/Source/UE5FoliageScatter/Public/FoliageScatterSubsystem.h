#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "FoliageScatterSubsystem.generated.h"

USTRUCT(BlueprintType)
struct FFoliageDensityRule
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    UStaticMesh* Mesh = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float MinSlopeDegrees = 0.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float MaxSlopeDegrees = 45.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float MinAltitude = -10000.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float MaxAltitude = 25000.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float DensityPerSquareKm = 5000.0f;
};

UCLASS()
class UE5FOLIAGESCATTER_API UFoliageScatterSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Foliage Scatter")
    int32 PopulateBiomeSector(FBox SectorBounds, const TArray<FFoliageDensityRule>& Rules, int32 Seed = 1337);
};
