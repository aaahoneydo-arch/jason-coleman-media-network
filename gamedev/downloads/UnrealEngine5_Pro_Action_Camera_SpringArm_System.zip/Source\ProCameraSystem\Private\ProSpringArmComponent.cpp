// Copyright (c) 2026 Jason Coleman Game Studios. All Rights Reserved.
#include "ProSpringArmComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

UProSpringArmComponent::UProSpringArmComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    bEnableCameraLag = true;
    CameraLagSpeed = 10.0f;
    bEnableCameraRotationLag = true;
    CameraRotationLagSpeed = 12.0f;
    TargetArmLength = 320.0f;
    ProbeSize = 12.0f;
    bDoCollisionTest = true;

    TargetSocketOffset = RightShoulderOffset;
    SocketOffset = RightShoulderOffset;
    TargetFOV = BaseFOV;
}

void UProSpringArmComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    // 1. Interpolate Shoulder Offset
    FVector DesiredOffset = (CurrentShoulder == ECameraShoulderState::Left) ? LeftShoulderOffset : RightShoulderOffset;
    if (bIsAiming)
    {
        DesiredOffset = (CurrentShoulder == ECameraShoulderState::Left) ? FVector(AimOffset.X, -AimOffset.Y, AimOffset.Z) : AimOffset;
    }

    SocketOffset = FMath::VInterpTo(SocketOffset, DesiredOffset, DeltaTime, ShoulderInterpSpeed);

    // 2. Dynamic Speed-Based FOV
    if (bEnableDynamicFOV)
    {
        ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
        if (OwnerCharacter && OwnerCharacter->GetCharacterMovement())
        {
            float CurrentSpeed = OwnerCharacter->GetVelocity().Size2D();
            float MaxWalkSpeed = OwnerCharacter->GetCharacterMovement()->MaxWalkSpeed;

            if (bIsAiming)
            {
                TargetFOV = AimFOV;
            }
            else
            {
                float SpeedRatio = FMath::Clamp(CurrentSpeed / FMath::Max(MaxWalkSpeed, 1.0f), 0.0f, 1.0f);
                TargetFOV = FMath::Lerp(BaseFOV, MaxSprintFOV, SpeedRatio);
            }

            // Find child camera to apply FOV
            TArray<USceneComponent*> Children;
            GetChildrenComponents(false, Children);
            for (USceneComponent* Child : Children)
            {
                UCameraComponent* Cam = Cast<UCameraComponent>(Child);
                if (Cam)
                {
                    Cam->FieldOfView = FMath::FInterpTo(Cam->FieldOfView, TargetFOV, DeltaTime, FOVInterpSpeed);
                    break;
                }
            }
        }
    }
}

void UProSpringArmComponent::ToggleShoulder()
{
    CurrentShoulder = (CurrentShoulder == ECameraShoulderState::Right) ? ECameraShoulderState::Left : ECameraShoulderState::Right;
}

void UProSpringArmComponent::SetAiming(bool bNewAiming)
{
    bIsAiming = bNewAiming;
}
