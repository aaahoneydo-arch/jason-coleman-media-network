// Copyright (c) 2026 Jason Coleman Game Studios. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SpringArmComponent.h"
#include "ProSpringArmComponent.generated.h"

UENUM(BlueprintType)
enum class ECameraShoulderState : uint8
{
    Right UMETA(DisplayName = "Right Shoulder"),
    Left  UMETA(DisplayName = "Left Shoulder"),
    Center UMETA(DisplayName = "Center Framing")
};

/**
 * Advanced SpringArm Component for Third-Person Action Games, Shooters, and Soulslikes in UE5.
 * Features speed-driven dynamic FOV, shoulder swapping, camera collision smoothing,
 * and aim-offset interpolation with zero per-frame garbage.
 */
UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class PROCAMERASYSTEM_API UProSpringArmComponent : public USpringArmComponent
{
    GENERATED_BODY()

public:
    UProSpringArmComponent();

    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Shoulder")
    ECameraShoulderState CurrentShoulder = ECameraShoulderState::Right;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Shoulder")
    FVector RightShoulderOffset = FVector(0.0f, 45.0f, 20.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Shoulder")
    FVector LeftShoulderOffset = FVector(0.0f, -45.0f, 20.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Shoulder")
    FVector AimOffset = FVector(0.0f, 30.0f, 10.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Interpolation")
    float ShoulderInterpSpeed = 8.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Dynamic FOV")
    bool bEnableDynamicFOV = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Dynamic FOV")
    float BaseFOV = 90.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Dynamic FOV")
    float MaxSprintFOV = 105.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Dynamic FOV")
    float AimFOV = 70.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pro Camera|Dynamic FOV")
    float FOVInterpSpeed = 6.0f;

    UPROPERTY(BlueprintReadOnly, Category = "Pro Camera|State")
    bool bIsAiming = false;

    UFUNCTION(BlueprintCallable, Category = "Pro Camera|Actions")
    void ToggleShoulder();

    UFUNCTION(BlueprintCallable, Category = "Pro Camera|Actions")
    void SetAiming(bool bNewAiming);

private:
    FVector TargetSocketOffset;
    float TargetFOV;
};
