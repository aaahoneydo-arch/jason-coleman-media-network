// Copyright (c) 2026 Jason Coleman Game Studios. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CameraTraumaShakeComponent.generated.h"

/**
 * Trauma-based Procedural Camera Shake Component for UE5.
 * Implements non-linear polynomial trauma response (Shake = Trauma^2)
 * driven by multi-frequency Perlin noise with continuous decay.
 */
UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class PROCAMERASYSTEM_API UCameraTraumaShakeComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UCameraTraumaShakeComponent();

    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Trauma")
    float TraumaDecayRate = 1.2f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Trauma|Limits")
    float MaxYawAngle = 4.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Trauma|Limits")
    float MaxPitchAngle = 4.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Trauma|Limits")
    float MaxRollAngle = 6.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Trauma|Limits")
    float MaxOffsetTranslation = 15.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Trauma|Frequency")
    float NoiseFrequency = 22.0f;

    UFUNCTION(BlueprintCallable, Category = "Camera Trauma")
    void AddTrauma(float Amount);

    UFUNCTION(BlueprintCallable, Category = "Camera Trauma")
    void SetTrauma(float NewTrauma);

    UFUNCTION(BlueprintPure, Category = "Camera Trauma")
    float GetCurrentTrauma() const { return CurrentTrauma; }

private:
    float CurrentTrauma = 0.0f;
    float TimeElapsed = 0.0f;
};
