# Unreal Engine 5 Pro Action Camera & SpringArm System

**Version 1.0.0** • **Commercial Royalty-Free License** • **Unreal Engine 5.0, 5.1, 5.2, 5.3, 5.4 & 5.5 Compatible**

A complete, production-ready third-person action camera framework for **Unreal Engine 5**. Designed for fast-paced action games, soulslikes, and third-person shooters.

---

## ⚡ Core Features

- **Pro SpringArm Component (`UProSpringArmComponent`):**
  - **Dynamic Speed-Based FOV:** Automatically expands camera field-of-view when sprinting or boosting, and tightens when aiming down sights (ADS).
  - **Shoulder Swapping:** Smoothly transitions between right-shoulder and left-shoulder framing with configurable interpolation speed.
  - **Collision Smoothing:** Pro-grade camera probe sphere that prevents sudden jarring snaps against walls and tight indoor geometry.
- **Camera Trauma Shake (`UCameraTraumaShakeComponent`):**
  - **Non-Linear Response:** Implements the GDC-standard polynomial model (`Shake = Trauma^2`), creating satisfying punchy reactions to hits, explosions, and recoil.
  - **Multi-Axis Perlin Noise:** Independent procedural noise curves for Pitch, Yaw, Roll, and XYZ translation with continuous linear/exponential decay.
- **Soulslike Target Lock-On (`UTargetLockOnComponent`):**
  - **Smart Target Selection:** Evaluates distance, camera forward dot product, and line-of-sight visibility traces to pick the best enemy target.
  - **Smooth Control Rotation:** Seamlessly rotates the player's camera to frame the locked target with customizable pitch and distance offsets.
  - **Automatic Break:** Breaks lock if the target dies, is destroyed, or moves beyond the break distance.

---

## 🚀 Installation & Setup

1. Copy the `ue5-pro-action-camera-springarm` folder into your Unreal Engine project's `Plugins/` directory (e.g. `YourProject/Plugins/ProCameraSystem/`).
2. Regenerate your project visual studio / IDE files (Right click `.uproject` > **Generate Visual Studio project files**).
3. Build your project in your IDE or open the Unreal Editor.
4. In your Character Blueprint:
   - Replace the default `SpringArm` with `ProSpringArmComponent`.
   - Add `CameraTraumaShakeComponent` and call `AddTrauma(0.4)` on hits or gunshots!
   - Add `TargetLockOnComponent` and call `ToggleLockOn()` when pressing Middle Mouse / Right Stick Click!

---

## 🛡️ Commercial License
Includes an unconditional, worldwide, royalty-free commercial license for personal and commercial Unreal Engine 5 projects.
