// Copyright (c) 2026 Jason Coleman Game Studios. All Rights Reserved.
#include "TargetLockOnComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"

UTargetLockOnComponent::UTargetLockOnComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
}

void UTargetLockOnComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (!CurrentLockedTarget) return;

    // Check if target is still valid, in range, and has line of sight
    ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwner());
    if (!OwnerCharacter || !IsValid(CurrentLockedTarget))
    {
        BreakLock();
        return;
    }

    float Dist = FVector::Dist(OwnerCharacter->GetActorLocation(), CurrentLockedTarget->GetActorLocation());
    if (Dist > BreakLockRadius || !HasLineOfSight(CurrentLockedTarget))
    {
        BreakLock();
        return;
    }

    // Orient PlayerController toward target with smooth interpolation
    APlayerController* PC = Cast<APlayerController>(OwnerCharacter->GetController());
    if (PC)
    {
        FVector TargetPos = CurrentLockedTarget->GetActorLocation() + TargetOffset;
        FVector CameraPos = PC->PlayerCameraManager ? PC->PlayerCameraManager->GetCameraLocation() : OwnerCharacter->GetActorLocation();
        
        FRotator LookAtRot = (TargetPos - CameraPos).Rotation();
        FRotator CurrentControlRot = PC->GetControlRotation();

        FRotator NewRot = FMath::RInterpTo(CurrentControlRot, LookAtRot, DeltaTime, RotationInterpSpeed);
        PC->SetControlRotation(NewRot);
    }
}

bool UTargetLockOnComponent::ToggleLockOn()
{
    if (CurrentLockedTarget)
    {
        BreakLock();
        return false;
    }

    AActor* BestTarget = FindBestTarget();
    if (BestTarget)
    {
        CurrentLockedTarget = BestTarget;
        OnTargetLockChanged.Broadcast(CurrentLockedTarget);
        return true;
    }

    return false;
}

void UTargetLockOnComponent::BreakLock()
{
    if (CurrentLockedTarget)
    {
        CurrentLockedTarget = nullptr;
        OnTargetLockChanged.Broadcast(nullptr);
    }
}

AActor* UTargetLockOnComponent::FindBestTarget()
{
    ACharacter* Owner = Cast<ACharacter>(GetOwner());
    if (!Owner) return nullptr;

    TArray<AActor*> OverlappingActors;
    TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;
    ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn));

    TArray<AActor*> ActorsToIgnore;
    ActorsToIgnore.Add(Owner);

    UKismetSystemLibrary::SphereOverlapActors(
        GetWorld(),
        Owner->GetActorLocation(),
        LockOnRadius,
        ObjectTypes,
        ACharacter::StaticClass(),
        ActorsToIgnore,
        OverlappingActors
    );

    AActor* BestActor = nullptr;
    float BestScore = -999999.0f;

    FVector Forward = Owner->GetActorForwardVector();
    FVector OwnerLocation = Owner->GetActorLocation();

    for (AActor* Potential : OverlappingActors)
    {
        if (!IsValid(Potential) || Potential == Owner) continue;

        FVector ToTarget = (Potential->GetActorLocation() - OwnerLocation).GetSafeNormal();
        float Dot = FVector::DotProduct(Forward, ToTarget);
        float Angle = FMath::RadiansToDegrees(FMath::Acos(Dot));

        if (Angle <= MaxLockOnAngle && HasLineOfSight(Potential))
        {
            float Distance = FVector::Dist(OwnerLocation, Potential->GetActorLocation());
            // Prioritize closer targets aligned with forward sight
            float Score = (Dot * 1000.0f) - (Distance * 0.5f);

            if (Score > BestScore)
            {
                BestScore = Score;
                BestActor = Potential;
            }
        }
    }

    return BestActor;
}

bool UTargetLockOnComponent::HasLineOfSight(AActor* TargetActor) const
{
    if (!TargetActor) return false;
    AActor* Owner = GetOwner();
    if (!Owner) return false;

    FHitResult Hit;
    FCollisionQueryParams Params;
    Params.AddIgnoredActor(Owner);
    Params.AddIgnoredActor(TargetActor);

    FVector Start = Owner->GetActorLocation() + FVector(0, 0, 50);
    FVector End = TargetActor->GetActorLocation() + FVector(0, 0, 50);

    bool bHit = GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params);
    return !bHit; // LOS clear if no hit
}
