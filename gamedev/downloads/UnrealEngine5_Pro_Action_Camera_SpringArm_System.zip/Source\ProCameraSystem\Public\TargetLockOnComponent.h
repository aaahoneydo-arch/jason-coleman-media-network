// Copyright (c) 2026 Jason Coleman Game Studios. All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "TargetLockOnComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTargetLockChanged, AActor*, NewTarget);

/**
 * Soulslike / Action-RPG Target Lock-On Component for UE5.
 * Scans, prioritizes, and locks camera control rotation onto target actors.
 * Handles distance falloff, line-of-sight obstruction checks, and smooth target switching.
 */
UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class PROCAMERASYSTEM_API UTargetLockOnComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UTargetLockOnComponent();

    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lock On|Ranges")
    float LockOnRadius = 1800.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lock On|Ranges")
    float BreakLockRadius = 2400.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lock On|Angles")
    float MaxLockOnAngle = 75.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lock On|Tracking")
    float RotationInterpSpeed = 7.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lock On|Offset")
    FVector TargetOffset = FVector(0.0f, 0.0f, 40.0f);

    UPROPERTY(BlueprintAssignable, Category = "Lock On|Events")
    FOnTargetLockChanged OnTargetLockChanged;

    UFUNCTION(BlueprintCallable, Category = "Lock On|Actions")
    bool ToggleLockOn();

    UFUNCTION(BlueprintCallable, Category = "Lock On|Actions")
    void BreakLock();

    UFUNCTION(BlueprintPure, Category = "Lock On|State")
    bool IsLockedOn() const { return CurrentLockedTarget != nullptr; }

    UFUNCTION(BlueprintPure, Category = "Lock On|State")
    AActor* GetLockedTarget() const { return CurrentLockedTarget; }

private:
    UPROPERTY()
    AActor* CurrentLockedTarget = nullptr;

    AActor* FindBestTarget();
    bool HasLineOfSight(AActor* TargetActor) const;
};
