// Copyright (c) 2026 Jason Coleman Game Studios. All Rights Reserved.
#include "CameraTraumaShakeComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/Actor.h"

UCameraTraumaShakeComponent::UCameraTraumaShakeComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
}

void UCameraTraumaShakeComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (CurrentTrauma <= 0.001f)
    {
        CurrentTrauma = 0.0f;
        return;
    }

    TimeElapsed += DeltaTime * NoiseFrequency;

    // Polynomial power-of-two trauma response
    float Shake = CurrentTrauma * CurrentTrauma;

    // Multi-dimensional Perlin noise sampling
    float PitchNoise = FMath::PerlinNoise1D(TimeElapsed) * MaxPitchAngle * Shake;
    float YawNoise   = FMath::PerlinNoise1D(TimeElapsed + 100.0f) * MaxYawAngle * Shake;
    float RollNoise  = FMath::PerlinNoise1D(TimeElapsed + 200.0f) * MaxRollAngle * Shake;

    float XNoise = FMath::PerlinNoise1D(TimeElapsed + 300.0f) * MaxOffsetTranslation * Shake;
    float YNoise = FMath::PerlinNoise1D(TimeElapsed + 400.0f) * MaxOffsetTranslation * Shake;
    float ZNoise = FMath::PerlinNoise1D(TimeElapsed + 500.0f) * MaxOffsetTranslation * Shake;

    // Apply rotation & offset to child camera component if present
    AActor* Owner = GetOwner();
    if (Owner)
    {
        UCameraComponent* Cam = Owner->FindComponentByClass<UCameraComponent>();
        if (Cam)
        {
            Cam->SetRelativeRotation(FRotator(PitchNoise, YawNoise, RollNoise));
            Cam->SetRelativeLocation(FVector(XNoise, YNoise, ZNoise));
        }
    }

    // Decay trauma over time
    CurrentTrauma = FMath::Clamp(CurrentTrauma - (TraumaDecayRate * DeltaTime), 0.0f, 1.0f);
}

void UCameraTraumaShakeComponent::AddTrauma(float Amount)
{
    CurrentTrauma = FMath::Clamp(CurrentTrauma + Amount, 0.0f, 1.0f);
}

void UCameraTraumaShakeComponent::SetTrauma(float NewTrauma)
{
    CurrentTrauma = FMath::Clamp(NewTrauma, 0.0f, 1.0f);
}
