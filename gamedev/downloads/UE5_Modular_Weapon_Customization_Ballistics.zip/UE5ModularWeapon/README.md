# Unreal Engine 5 Modular Weapon Customization & Ballistics

High-precision firearm component attachment architecture and trajectory projectile physics for military shooters and tactical games in Unreal Engine 5.3, 5.4, and 5.5.

## Architecture
- **Modular Socket Hierarchy**: Muzzles, optics, grips, stocks, and magazines dynamically modify recoil damping and weapon weight balance.
- **Air Drag & Gravity Drop**: Realistic ballistic solver accurately computes bullet drop and flight time over kilometers.
- **Procedural Spring Recoil**: 3-DOF spring damper camera impulse with zero hardcoded animation dependency.
