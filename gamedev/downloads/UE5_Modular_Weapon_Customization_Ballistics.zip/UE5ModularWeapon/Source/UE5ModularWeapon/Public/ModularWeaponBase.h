#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ModularWeaponBase.generated.h"

UENUM(BlueprintType)
enum class EAttachmentSocket : uint8
{
    Muzzle       UMETA(DisplayName = "Muzzle Brake / Suppressor"),
    Optic        UMETA(DisplayName = "Optic / Red Dot / Scope"),
    Underbarrel  UMETA(DisplayName = "Foregrip / Bipod"),
    Magazine     UMETA(DisplayName = "Magazine Assembly"),
    Stock        UMETA(DisplayName = "Buttstock")
};

USTRUCT(BlueprintType)
struct FBallisticProjectileSimulation
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadWrite)
    FVector CurrentPosition = FVector::ZeroVector;

    UPROPERTY(BlueprintReadWrite)
    FVector Velocity = FVector::ZeroVector;

    UPROPERTY(BlueprintReadWrite)
    float DragCoefficient = 0.00045f;

    UPROPERTY(BlueprintReadWrite)
    float CaliberGrainMass = 55.0f; // 5.56x45mm NATO standard
};

UCLASS()
class UE5MODULARWEAPON_API AModularWeaponBase : public AActor
{
    GENERATED_BODY()

public:
    AModularWeaponBase();

    UFUNCTION(BlueprintCallable, Category = "Weapon|Attachments")
    bool AttachComponentToSocket(EAttachmentSocket Socket, UStaticMesh* AttachmentMesh);

    UFUNCTION(BlueprintCallable, Category = "Weapon|Ballistics")
    void FireBallisticRound(FVector MuzzleLocation, FVector FiringVector);
};
