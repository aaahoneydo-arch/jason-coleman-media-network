#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyAtmosphereComponent.h"
#include "CelestialTimeController.generated.h"

UENUM(BlueprintType)
enum class EWeatherCondition : uint8
{
    ClearSky       UMETA(DisplayName = "Clear Sky"),
    PartlyCloudy   UMETA(DisplayName = "Partly Cloudy"),
    OvercastStorm  UMETA(DisplayName = "Overcast Rainstorm"),
    DenseFog       UMETA(DisplayName = "Dense Morning Fog"),
    Blizzard       UMETA(DisplayName = "Freezing Blizzard")
};

UCLASS()
class UE5WEATHERCELESTIAL_API ACelestialTimeController : public AActor
{
    GENERATED_BODY()

public:
    ACelestialTimeController();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Celestial|Time")
    float TimeOfDayHours = 12.0f; // 0 to 24

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Celestial|Time")
    float DayCycleDurationMinutes = 30.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Celestial|Weather")
    EWeatherCondition CurrentWeather = EWeatherCondition::ClearSky;

    UFUNCTION(BlueprintCallable, Category = "Celestial")
    void SetTimeOfDay(float NewHours);

    UFUNCTION(BlueprintCallable, Category = "Celestial")
    void TransitionWeather(EWeatherCondition NewWeather, float BlendDurationSeconds);

protected:
    virtual void Tick(float DeltaTime) override;
};
