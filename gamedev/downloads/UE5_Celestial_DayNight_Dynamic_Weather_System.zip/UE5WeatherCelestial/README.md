# Unreal Engine 5 Celestial Day-Night & Dynamic Weather System

Astronomical sun/moon ephemeris, Volumetric Cloud layer transition blending, and dynamic PBR wetness materials for Unreal Engine 5.3, 5.4, and 5.5.

## Architecture
- **Ephemeris Sun Positioning**: True geographic latitude/longitude solar trajectory calculations.
- **Volumetric Cloud Shaders**: Smooth interpolations between clear skies, cumulus clusters, and stormy nimbo-stratus.
- **Lumen & Nanite Tuned**: Zero lighting artifacts or light bleed during midnight and twilight transitions.
