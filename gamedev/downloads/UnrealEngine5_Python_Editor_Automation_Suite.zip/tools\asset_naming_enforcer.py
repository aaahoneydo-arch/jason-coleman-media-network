"""
Unreal Engine 5 Python Automation Tool: Asset Naming Enforcer
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Scans the selected Content Browser folder (or entire /Game/ directory)
and enforces official Epic Games naming prefixes (SM_, T_, M_, MI_, BP_, WBP_, etc.).
Safely renames assets using EditorAssetLibrary and registers clean redirectors.
"""

import unreal

# Standard Epic Games naming conventions
PREFIX_MAPPING = {
    unreal.StaticMesh: "SM_",
    unreal.SkeletalMesh: "SK_",
    unreal.Texture2D: "T_",
    unreal.TextureCube: "TC_",
    unreal.Material: "M_",
    unreal.MaterialInstanceConstant: "MI_",
    unreal.MaterialFunction: "MF_",
    unreal.Blueprint: "BP_",
    unreal.WidgetBlueprint: "WBP_",
    unreal.SoundCue: "SC_",
    unreal.SoundWave: "SW_",
    unreal.NiagaraSystem: "NS_",
    unreal.NiagaraEmitter: "NE_",
    unreal.AnimSequence: "AS_",
    unreal.AnimMontage: "AM_",
    unreal.BlendSpace: "BS_",
    unreal.Skeleton: "SKEL_",
    unreal.PhysicsAsset: "PHYS_",
}

def enforce_asset_naming(target_path="/Game/"):
    """Scans and corrects asset naming prefixes in target_path."""
    asset_lib = unreal.EditorAssetLibrary()
    asset_registry = unreal.AssetRegistryHelpers.get_asset_registry()
    
    unreal.log(f"[NamingEnforcer] Scanning assets under {target_path}...")
    assets = asset_lib.list_assets(target_path, recursive=True, include_folder=False)
    
    renamed_count = 0
    skipped_count = 0

    for asset_path in assets:
        asset_data = asset_lib.find_asset_data(asset_path)
        asset_class = asset_data.get_class()
        asset_name = asset_data.asset_name
        
        # Check if asset matches prefix rule
        expected_prefix = None
        for cls, prefix in PREFIX_MAPPING.items():
            if asset_class.is_child_of(cls.static_class()):
                expected_prefix = prefix
                break
                
        if not expected_prefix:
            skipped_count += 1
            continue

        if not str(asset_name).startswith(expected_prefix):
            new_name = f"{expected_prefix}{asset_name}"
            folder_path = unreal.Paths.get_path(asset_path)
            new_asset_path = f"{folder_path}/{new_name}"
            
            success = asset_lib.rename_asset(asset_path, new_asset_path)
            if success:
                renamed_count += 1
                unreal.log(f"[NamingEnforcer] Renamed: {asset_name} -> {new_name}")
            else:
                unreal.log_warning(f"[NamingEnforcer] Failed to rename: {asset_path}")

    unreal.log(f"[NamingEnforcer] Complete! Renamed: {renamed_count}, Skipped/Compliant: {skipped_count}")

if __name__ == "__main__":
    enforce_asset_naming("/Game/")
