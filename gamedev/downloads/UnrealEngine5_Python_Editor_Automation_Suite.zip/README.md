# Unreal Engine 5 Python Editor Automation Suite (15+ Pro Tools)

**Version 1.0.0** • **Commercial Royalty-Free License** • **Compatible with Unreal Engine 5.0, 5.1, 5.2, 5.3, 5.4 & 5.5**

A battle-tested production toolkit of **15 Python automation scripts** designed to eliminate repetitive technical artist & level designer grunt work in Unreal Engine 5.

---

## ⚡ Included Automation Tools

1. **Asset Naming Enforcer (`asset_naming_enforcer.py`):** Automatically enforces Epic Games naming conventions (`SM_`, `T_`, `M_`, `MI_`, `BP_`, `WBP_`, etc.) across selected folders or `/Game/` with safe redirector tracking.
2. **Auto LOD Chain Generator (`auto_lod_chain_generator.py`):** Generates 4-tier LOD chains with screen size reduction curves and triangle reduction percentages for non-Nanite static meshes.
3. **Batch Material Instance Creator (`batch_material_instance_creator.py`):** Groups texture sets by base name (Albedo, Normal, ORM, AO, Emissive) and instantiates configured Material Instances from master materials.
4. **Texture VRAM & Compression Optimizer (`texture_vram_optimizer.py`):** Configures Normal maps to `TC_Normalmap` (sRGB off), ORM masks to `TC_Masks` (sRGB off), and clamps maximum in-game resolutions (2K, 4K).
5. **Collision Hull Auto-Generator (`collision_hull_auto_generator.py`):** Batch creates Box, Sphere, Capsule, or Auto-Convex hulls for static meshes lacking simple collisions.
6. **Redirector Cleanup & Fixer (`redirector_cleanup_fixer.py`):** Automatically finds and fixes dirty `ObjectRedirector` assets and cleans stale file references.
7. **Level Duplicate Actor Cleaner (`level_duplicate_cleaner.py`):** Scans active world levels for overlapping duplicate actors sharing identical transforms and cleans up empty outliner folders.
8. **Nanite Batch Toggle (`nanite_batch_toggle.py`):** 1-click batch enables or disables Nanite geometry virtualization and configures fallback triangle percent.
9. **Audio Cue Batch Builder (`audio_cue_batch_builder.py`):** Automatically creates Sound Cues for imported WAV sound effects.
10. **Empty Folder Pruner (`empty_folder_pruner.py`):** Purges ghost directories left behind by Git/Perforce branch merges.
11. **Unreferenced Asset Auditor (`unreferenced_asset_audit.py`):** Exports a comprehensive CSV audit report of orphaned assets consuming disk space.
12. **Master Tools Launcher (`master_tools_launcher.py`):** Unified menu interface to run any tool with a single command.

---

## 🚀 Quick Start
1. Ensure the **Python Editor Script Plugin** and **Editor Scripting Utilities** are enabled in **Edit > Plugins**.
2. Open the **Output Log** in Unreal Engine 5.
3. Switch log mode to **Python** (bottom left).
4. Run:
   ```python
   py "C:/Path/To/tools/master_tools_launcher.py"
   ```

---

## 🛡️ Commercial License
Includes a 100% royalty-free, perpetual commercial license for use in unlimited commercial or personal Unreal Engine 5 game projects.
