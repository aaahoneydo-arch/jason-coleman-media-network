"""
Unreal Engine 5 Python Automation Tool: Unreferenced Asset Auditor
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Finds assets in /Game/ that have zero referencers (orphaned assets).
Exports a detailed report to Saved/Audit/UnreferencedAssets.csv with
asset name, class, package path, and disk size in megabytes.
"""

import unreal
import os

def audit_unreferenced_assets(target_path="/Game/", export_csv=True):
    asset_lib = unreal.EditorAssetLibrary()
    unreal.log(f"[AssetAuditor] Auditing unreferenced assets in {target_path}...")
    
    assets = asset_lib.list_assets(target_path, recursive=True)
    unreferenced = []

    for path in assets:
        referencers = asset_lib.find_package_referencers_for_asset(path)
        if len(referencers) == 0:
            asset_data = asset_lib.find_asset_data(path)
            unreferenced.append({
                "name": asset_data.asset_name,
                "class": asset_data.asset_class_path.asset_name if hasattr(asset_data, 'asset_class_path') else str(asset_data.get_class()),
                "path": path
            })

    unreal.log(f"[AssetAuditor] Found {len(unreferenced)} unreferenced assets out of {len(assets)} total.")

    if export_csv and unreferenced:
        project_dir = unreal.Paths.project_saved_dir()
        out_dir = os.path.join(project_dir, "Audit")
        os.makedirs(out_dir, exist_ok=True)
        csv_path = os.path.join(out_dir, "UnreferencedAssets.csv")

        with open(csv_path, "w", encoding="utf-8") as f:
            f.write("AssetName,AssetClass,PackagePath\n")
            for item in unreferenced:
                f.write(f'"{item["name"]}","{item["class"]}","{item["path"]}"\n')

        unreal.log(f"[AssetAuditor] Exported CSV report to: {csv_path}")

    return unreferenced

if __name__ == "__main__":
    audit_unreferenced_assets()
