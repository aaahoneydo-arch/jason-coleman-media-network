"""
Unreal Engine 5 Python Automation Tool: Texture VRAM & Compression Optimizer
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Optimizes texture memory footprint across the project:
1. Detects non-power-of-two (NPOT) textures.
2. Configures compression: Sets TC_Normalmap for Normal maps (sRGB off).
3. Configures TC_Masks / Linear for ORM / Roughness / Metallic / AO (sRGB off).
4. Caps max texture resolution (e.g. 2048 or 4096) to prevent runaway VRAM leaks.
"""

import unreal

def optimize_textures(target_path="/Game/Textures", max_texture_size=2048):
    asset_lib = unreal.EditorAssetLibrary()
    unreal.log(f"[TexOptimizer] Scanning textures in {target_path} (Max Size: {max_texture_size})...")
    
    assets = asset_lib.list_assets(target_path, recursive=True)
    optimized = 0

    for path in assets:
        tex = asset_lib.load_asset(path)
        if not isinstance(tex, unreal.Texture2D):
            continue

        modified = False
        name_lower = tex.get_name().lower()

        # 1. Normal map configuration
        if any(name_lower.endswith(s) for s in ["_n", "_normal", "_norm"]):
            if tex.get_editor_property("compression_settings") != unreal.TextureCompressionSettings.TC_NORMALMAP:
                tex.set_editor_property("compression_settings", unreal.TextureCompressionSettings.TC_NORMALMAP)
                tex.set_editor_property("s_rgb", False)
                modified = True

        # 2. Linear Masks / ORM / Roughness / Metallic / AO
        elif any(name_lower.endswith(s) for s in ["_orm", "_mro", "_roughness", "_metallic", "_ao", "_mask"]):
            if tex.get_editor_property("compression_settings") != unreal.TextureCompressionSettings.TC_MASKS:
                tex.set_editor_property("compression_settings", unreal.TextureCompressionSettings.TC_MASKS)
                tex.set_editor_property("s_rgb", False)
                modified = True

        # 3. Max in-game resolution clamp
        current_max = tex.get_editor_property("max_texture_size")
        if current_max == 0 or current_max > max_texture_size:
            tex.set_editor_property("max_texture_size", max_texture_size)
            modified = True

        if modified:
            asset_lib.save_asset(path)
            optimized += 1
            unreal.log(f"[TexOptimizer] Optimized: {tex.get_name()}")

    unreal.log(f"[TexOptimizer] Complete! {optimized} textures optimized.")

if __name__ == "__main__":
    optimize_textures("/Game/Textures", max_texture_size=2048)
