"""
Unreal Engine 5 Python Automation Tool: Nanite Batch Toggle & Optimization
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

One-click batch enables or disables Nanite geometry virtualization
across selected folders of Static Meshes. Configures fallback percent triangles
and relative error settings.
"""

import unreal

def batch_set_nanite(target_path="/Game/Meshes", enable_nanite=True, fallback_percent_triangles=1.0):
    asset_lib = unreal.EditorAssetLibrary()
    unreal.log(f"[NaniteToggle] Scanning static meshes in {target_path} (Enable={enable_nanite})...")

    assets = asset_lib.list_assets(target_path, recursive=True)
    count = 0

    for path in assets:
        mesh = asset_lib.load_asset(path)
        if isinstance(mesh, unreal.StaticMesh):
            nanite_settings = mesh.get_editor_property("nanite_settings")
            if nanite_settings:
                current_state = nanite_settings.get_editor_property("enabled")
                if current_state != enable_nanite:
                    nanite_settings.set_editor_property("enabled", enable_nanite)
                    nanite_settings.set_editor_property("fallback_percent_triangles", fallback_percent_triangles)
                    mesh.set_editor_property("nanite_settings", nanite_settings)
                    asset_lib.save_asset(path)
                    count += 1
                    unreal.log(f"[NaniteToggle] Set Nanite={enable_nanite} on: {mesh.get_name()}")

    unreal.log(f"[NaniteToggle] Updated {count} static meshes.")

if __name__ == "__main__":
    batch_set_nanite("/Game/Meshes", enable_nanite=True)
