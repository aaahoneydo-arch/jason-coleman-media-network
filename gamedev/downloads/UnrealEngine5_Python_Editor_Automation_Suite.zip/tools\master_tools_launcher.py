"""
Unreal Engine 5 Python Master Automation Launcher
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Provides an interactive console & menu inside Unreal Engine's Python Terminal
to execute any automation tool with one command:
    py "path/to/tools/master_tools_launcher.py"
"""

import unreal
import sys
import os

TOOLS_REGISTRY = [
    ("1", "Asset Naming Enforcer (SM_, T_, M_, MI_, BP_)", "asset_naming_enforcer"),
    ("2", "Auto LOD Chain Generator (LOD0-LOD3)", "auto_lod_chain_generator"),
    ("3", "Batch Material Instance Creator (PBR Auto-Wiring)", "batch_material_instance_creator"),
    ("4", "Texture VRAM & Compression Optimizer (2K/4K, TC_Normalmap)", "texture_vram_optimizer"),
    ("5", "Collision Hull Auto-Generator (Convex, Box, Sphere)", "collision_hull_auto_generator"),
    ("6", "Redirector Cleanup & Fixer", "redirector_cleanup_fixer"),
    ("7", "Level Duplicate Actor Cleaner", "level_duplicate_cleaner"),
    ("8", "Nanite Batch Toggle & Error Configurator", "nanite_batch_toggle"),
    ("9", "Audio Cue Batch Builder", "audio_cue_batch_builder"),
    ("10", "Empty Folder Pruner", "empty_folder_pruner"),
    ("11", "Unreferenced Asset Auditor (CSV Export)", "unreferenced_asset_audit")
]

def show_menu():
    unreal.log("=====================================================")
    unreal.log("⚡ UNREAL ENGINE 5 PYTHON AUTOMATION SUITE (PRO) ⚡")
    unreal.log("=====================================================")
    for key, name, _ in TOOLS_REGISTRY:
        unreal.log(f" [{key}] {name}")
    unreal.log("=====================================================")
    unreal.log("To run a tool directly in Output Log or Python Console:")
    unreal.log("  import sys; sys.path.append(r'C:/Path/To/Tools')")
    unreal.log("  import asset_naming_enforcer; asset_naming_enforcer.enforce_asset_naming('/Game/')")

if __name__ == "__main__":
    show_menu()
