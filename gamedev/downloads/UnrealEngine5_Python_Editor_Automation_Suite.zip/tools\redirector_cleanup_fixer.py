"""
Unreal Engine 5 Python Automation Tool: Redirector Cleanup & Fixer
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Finds and resolves all dirty redirector assets across the /Game/ folder hierarchy.
Fixes references pointing through redirectors and safely purges deleted placeholders.
"""

import unreal

def fix_all_redirectors(target_path="/Game/"):
    asset_lib = unreal.EditorAssetLibrary()
    unreal.log(f"[RedirectorFixer] Scanning for ObjectRedirectors in {target_path}...")

    asset_registry = unreal.AssetRegistryHelpers.get_asset_registry()
    filter_data = unreal.ARFilter(
        class_names=["ObjectRedirector"],
        package_paths=[target_path],
        recursive_paths=True
    )

    redirectors_data = asset_registry.get_assets(filter_data)
    if not redirectors_data:
        unreal.log("[RedirectorFixer] No redirectors found. Clean project!")
        return

    redirector_objects = []
    for r_data in redirectors_data:
        obj = r_data.get_asset()
        if obj:
            redirector_objects.append(obj)

    unreal.log(f"[RedirectorFixer] Found {len(redirector_objects)} redirectors. Fixing references...")
    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
    asset_tools.fix_up_redirectors(redirector_objects)

    unreal.log("[RedirectorFixer] All redirectors successfully resolved and cleaned!")

if __name__ == "__main__":
    fix_all_redirectors("/Game/")
