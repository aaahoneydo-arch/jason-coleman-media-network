"""
Unreal Engine 5 Python Automation Tool: Batch Material Instance Creator
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Automatically groups textures by asset name prefix/suffix and creates
Material Instances inheriting from a master base material (M_Master_PBR).
Wired parameters: BaseColor / Albedo, Normal, ORM / Roughness / Metallic, AO, Emissive.
"""

import unreal
import re

TEXTURE_SUFFIXES = {
    "BaseColor": ["_basecolor", "_albedo", "_d", "_diffuse", "_bc", "_col"],
    "Normal": ["_normal", "_n", "_norm"],
    "ORM": ["_orm", "_mro", "_roughness_metallic", "_rma"],
    "Roughness": ["_roughness", "_r", "_rough"],
    "Metallic": ["_metallic", "_m", "_metal"],
    "AO": ["_ao", "_ambientocclusion", "_occlusion"],
    "Emissive": ["_emissive", "_e", "_emit"]
}

def batch_create_material_instances(
    texture_folder="/Game/Textures",
    master_material_path="/Game/Materials/M_Master_PBR",
    destination_folder="/Game/Materials/Instances"
):
    asset_lib = unreal.EditorAssetLibrary()
    material_editing_lib = unreal.MaterialEditingLibrary()
    
    master_mat = asset_lib.load_asset(master_material_path)
    if not master_mat:
        unreal.log_warning(f"[BatchMI] Master material not found at: {master_material_path}")
        return

    unreal.log(f"[BatchMI] Scanning textures under: {texture_folder}...")
    assets = asset_lib.list_assets(texture_folder, recursive=True)
    
    # Group textures by base token
    groups = {} # base_name -> { "BaseColor": tex, "Normal": tex, ... }
    
    for path in assets:
        tex = asset_lib.load_asset(path)
        if not isinstance(tex, unreal.Texture2D):
            continue
            
        tex_name = tex.get_name().lower()
        matched_slot = None
        clean_base = tex_name
        
        for slot, suffixes in TEXTURE_SUFFIXES.items():
            for suffix in suffixes:
                if tex_name.endswith(suffix):
                    matched_slot = slot
                    clean_base = re.sub(f"{suffix}$", "", tex_name)
                    break
            if matched_slot:
                break
                
        if matched_slot:
            if clean_base not in groups:
                groups[clean_base] = {}
            groups[clean_base][matched_slot] = tex

    created_count = 0
    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()

    for base_name, tex_dict in groups.items():
        mi_name = f"MI_{base_name.capitalize()}"
        mi_factory = unreal.MaterialInstanceConstantFactoryNew()
        
        mi_asset = asset_tools.create_asset(
            mi_name,
            destination_folder,
            unreal.MaterialInstanceConstant,
            mi_factory
        )
        
        if mi_asset:
            material_editing_lib.set_material_instance_parent(mi_asset, master_mat)
            
            for param_name, tex_obj in tex_dict.items():
                material_editing_lib.set_material_instance_texture_parameter_value(
                    mi_asset,
                    param_name,
                    tex_obj
                )
                
            material_editing_lib.update_material_instance(mi_asset)
            asset_lib.save_asset(f"{destination_folder}/{mi_name}")
            created_count += 1
            unreal.log(f"[BatchMI] Created: {mi_name} with {len(tex_dict)} textures assigned.")

    unreal.log(f"[BatchMI] Complete! Successfully generated {created_count} Material Instances.")

if __name__ == "__main__":
    batch_create_material_instances()
