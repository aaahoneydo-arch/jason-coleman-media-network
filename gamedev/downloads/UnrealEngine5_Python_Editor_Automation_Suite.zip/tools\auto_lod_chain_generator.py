"""
Unreal Engine 5 Python Automation Tool: Auto LOD Chain Generator
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Automatically generates 4-tier LOD chains (LOD0-LOD3) for non-Nanite Static Meshes.
Configures screen-size reduction thresholds and percent triangles automatically.
"""

import unreal

def generate_lod_chains(target_path="/Game/Meshes", num_lods=4):
    """Batch generates LOD chains for static meshes under target_path."""
    asset_lib = unreal.EditorAssetLibrary()
    mesh_editor_lib = unreal.EditorStaticMeshLibrary()

    unreal.log(f"[AutoLOD] Finding static meshes in {target_path}...")
    assets = asset_lib.list_assets(target_path, recursive=True)
    
    processed = 0
    # Standard screen size & triangle reduction curves
    lod_settings = [
        {"screen_size": 1.0, "tri_percent": 1.00},   # LOD0: 100%
        {"screen_size": 0.5, "tri_percent": 0.50},   # LOD1: 50%
        {"screen_size": 0.25, "tri_percent": 0.25},  # LOD2: 25%
        {"screen_size": 0.08, "tri_percent": 0.10},  # LOD3: 10%
    ]

    for asset_path in assets:
        asset = asset_lib.load_asset(asset_path)
        if isinstance(asset, unreal.StaticMesh):
            # Skip if Nanite is enabled (Nanite manages micro-geometry dynamically)
            nanite_settings = asset.get_editor_property("nanite_settings")
            if nanite_settings and nanite_settings.get_editor_property("enabled"):
                continue

            current_lods = mesh_editor_lib.get_lod_count(asset)
            if current_lods < num_lods:
                # Set custom reduction options
                options = unreal.EditorScriptingMeshReductionOptions()
                reduction_settings = []
                
                for idx, setting in enumerate(lod_settings[:num_lods]):
                    rs = unreal.EditorScriptingMeshReductionSettings()
                    rs.percent_triangles = setting["tri_percent"]
                    rs.screen_size = setting["screen_size"]
                    reduction_settings.append(rs)

                options.reduction_settings = reduction_settings
                mesh_editor_lib.set_lods_with_reduction(asset, options)
                asset_lib.save_asset(asset_path)
                processed += 1
                unreal.log(f"[AutoLOD] Generated {num_lods} LODs for: {asset.get_name()}")

    unreal.log(f"[AutoLOD] Finished generating LODs for {processed} static meshes.")

if __name__ == "__main__":
    generate_lod_chains("/Game/")
