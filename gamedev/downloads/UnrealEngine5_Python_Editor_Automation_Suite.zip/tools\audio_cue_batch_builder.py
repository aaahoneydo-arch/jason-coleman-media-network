"""
Unreal Engine 5 Python Automation Tool: Audio Cue Batch Builder
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Automatically builds Sound Cues for newly imported Sound Waves (WAV).
Creates and configures SoundCue assets with appropriate naming (SC_ prefix)
and saves them to the destination Audio folder.
"""

import unreal

def batch_create_sound_cues(sound_wave_folder="/Game/Audio/Waves", destination_folder="/Game/Audio/Cues"):
    asset_lib = unreal.EditorAssetLibrary()
    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()

    unreal.log(f"[AudioCueBuilder] Scanning SoundWaves in {sound_wave_folder}...")
    assets = asset_lib.list_assets(sound_wave_folder, recursive=True)
    created = 0

    for path in assets:
        wave = asset_lib.load_asset(path)
        if isinstance(wave, unreal.SoundWave):
            base_name = wave.get_name()
            if base_name.startswith("SW_"):
                cue_name = f"SC_{base_name[3:]}"
            else:
                cue_name = f"SC_{base_name}"

            cue_path = f"{destination_folder}/{cue_name}"
            if not asset_lib.does_asset_exist(cue_path):
                cue_factory = unreal.SoundCueFactoryNew()
                cue_asset = asset_tools.create_asset(cue_name, destination_folder, unreal.SoundCue, cue_factory)
                if cue_asset:
                    asset_lib.save_asset(cue_path)
                    created += 1
                    unreal.log(f"[AudioCueBuilder] Created SoundCue: {cue_name}")

    unreal.log(f"[AudioCueBuilder] Finished! Created {created} Sound Cues.")

if __name__ == "__main__":
    batch_create_sound_cues()
