"""
Unreal Engine 5 Python Automation Tool: Collision Hull Auto-Generator
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Automatically generates simplified collision bodies for Static Meshes
lacking simple collision hulls. Supports Box, Sphere, Capsule, and
Auto-Convex generation with customizable hull count and vertex resolution.
"""

import unreal

def generate_simple_collision(target_path="/Game/Meshes", collision_type="CONVEX", hull_count=4, max_hull_verts=16):
    asset_lib = unreal.EditorAssetLibrary()
    mesh_lib = unreal.EditorStaticMeshLibrary()

    unreal.log(f"[CollisionGen] Scanning static meshes in {target_path}...")
    assets = asset_lib.list_assets(target_path, recursive=True)
    generated = 0

    for path in assets:
        mesh = asset_lib.load_asset(path)
        if not isinstance(mesh, unreal.StaticMesh):
            continue

        body_setup = mesh.get_editor_property("body_setup")
        # Check if mesh has simple collision already
        has_simple_collision = False
        if body_setup:
            agg_geom = body_setup.get_editor_property("agg_geom")
            if (len(agg_geom.get_editor_property("box_elems")) > 0 or
                len(agg_geom.get_editor_property("sphere_elems")) > 0 or
                len(agg_geom.get_editor_property("sphyl_elems")) > 0 or
                len(agg_geom.get_editor_property("convex_elems")) > 0):
                has_simple_collision = True

        if not has_simple_collision:
            if collision_type.upper() == "BOX":
                mesh_lib.add_simple_collisions(mesh, unreal.ScriptingCollisionShapeType.BOX)
            elif collision_type.upper() == "SPHERE":
                mesh_lib.add_simple_collisions(mesh, unreal.ScriptingCollisionShapeType.SPHERE)
            elif collision_type.upper() == "CAPSULE":
                mesh_lib.add_simple_collisions(mesh, unreal.ScriptingCollisionShapeType.CAPSULE)
            else: # AUTO CONVEX
                mesh_lib.set_convex_decomposition_collisions(
                    mesh,
                    hull_count=hull_count,
                    max_hull_verts=max_hull_verts,
                    hull_precision=100000
                )

            asset_lib.save_asset(path)
            generated += 1
            unreal.log(f"[CollisionGen] Added {collision_type} collision to: {mesh.get_name()}")

    unreal.log(f"[CollisionGen] Done! Generated collisions for {generated} meshes.")

if __name__ == "__main__":
    generate_simple_collision("/Game/Meshes", collision_type="CONVEX")
