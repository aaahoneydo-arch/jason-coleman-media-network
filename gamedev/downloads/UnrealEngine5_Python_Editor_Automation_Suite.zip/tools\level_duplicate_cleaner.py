"""
Unreal Engine 5 Python Automation Tool: Level Duplicate Cleaner
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Analyzes the currently active Level / World and identifies duplicate actors
sharing identical locations, rotations, scales, and mesh components.
Optionally removes or selects duplicates for artist review.
"""

import unreal

def clean_duplicate_actors(tolerance=0.01, delete_duplicates=False):
    actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    all_actors = actor_subsystem.get_all_level_actors()
    
    unreal.log(f"[LevelCleaner] Inspecting {len(all_actors)} actors in active level...")
    seen_transforms = {} # (x, y, z, pitch, yaw, roll, class_name) -> actor
    duplicates = []

    for actor in all_actors:
        if not actor or not actor_subsystem.is_valid_actor(actor):
            continue

        loc = actor.get_actor_location()
        rot = actor.get_actor_rotation()
        cls_name = actor.get_class().get_name()

        # Quantize key by tolerance
        key = (
            round(loc.x / tolerance),
            round(loc.y / tolerance),
            round(loc.z / tolerance),
            round(rot.pitch / tolerance),
            round(rot.yaw / tolerance),
            round(rot.roll / tolerance),
            cls_name
        )

        if key in seen_transforms:
            duplicates.append(actor)
            unreal.log_warning(f"[LevelCleaner] Duplicate detected: {actor.get_actor_label()} overlaps {seen_transforms[key].get_actor_label()}")
        else:
            seen_transforms[key] = actor

    unreal.log(f"[LevelCleaner] Found {len(duplicates)} duplicate overlapping actors.")

    if delete_duplicates and duplicates:
        for dup in duplicates:
            actor_subsystem.destroy_actor(dup)
        unreal.log(f"[LevelCleaner] Destroyed {len(duplicates)} duplicate actors.")
    elif duplicates:
        actor_subsystem.select_nothing()
        for dup in duplicates:
            actor_subsystem.set_actor_selection_state(dup, True)
        unreal.log(f"[LevelCleaner] Selected {len(duplicates)} duplicate actors in World Outliner.")

if __name__ == "__main__":
    clean_duplicate_actors(delete_duplicates=False)
