# Unreal Engine 5 Python Editor Setup Guide

## 1. Enabling Python in Unreal Engine 5

Unreal Engine 5 comes with Python 3 embedded directly into the editor, but the plugins must be enabled:
1. Open your project in **Unreal Engine 5** (5.0, 5.1, 5.2, 5.3, 5.4, or 5.5).
2. Go to **Edit > Plugins**.
3. Search for **Python** in the search bar.
4. Enable the following plugins:
   - **Python Editor Script Plugin** (Built-in)
   - **Editor Scripting Utilities** (Built-in)
5. Restart the Unreal Editor when prompted.

---

## 2. Running Scripts

### Method A: Output Log (Fastest)
1. Open **Window > Output Log** (or press `` ` `` or `Ctrl + ~`).
2. At the bottom left of the Output Log, change the dropdown from **Cmd** to **Python**.
3. Type or paste:
   ```python
   py "C:/Path/To/ue5-python-automation-suite/tools/asset_naming_enforcer.py"
   ```
   Press **Enter**!

### Method B: Adding to Startup Scripts
To have the tools available globally on editor startup:
1. Go to **Edit > Project Settings > Plugins > Python**.
2. Under **Additional Paths**, add the folder containing these scripts:
   `C:/YourProject/Tools/ue5-python-automation-suite/tools/`
3. Now you can type directly into the Python terminal:
   ```python
   import asset_naming_enforcer
   asset_naming_enforcer.enforce_asset_naming("/Game/MyFolder")
   ```

### Method C: Editor Utility Blueprints / Widgets
You can bind these scripts to custom editor buttons, context menu items, or toolbar buttons using the **Execute Python Command** node in any Editor Utility Widget!
