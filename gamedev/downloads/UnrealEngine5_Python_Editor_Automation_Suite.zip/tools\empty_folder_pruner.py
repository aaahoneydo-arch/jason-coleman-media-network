"""
Unreal Engine 5 Python Automation Tool: Empty Folder Pruner
Author: Jason Coleman Game Studios
Compatible: Unreal Engine 5.0 - 5.5

Recursively walks the /Game/ Content tree and deletes empty directories
that no longer contain assets or valid child folders. Eliminates
ghost directories left by source control branch switching.
"""

import unreal

def prune_empty_folders(target_path="/Game/"):
    asset_lib = unreal.EditorAssetLibrary()
    unreal.log(f"[FolderPruner] Scanning for empty folders under {target_path}...")
    
    subdirs = asset_lib.list_assets(target_path, recursive=True, include_folder=True)
    # Filter only folders
    folders = [p for p in subdirs if asset_lib.does_directory_exist(p)]
    # Sort by depth descending so deepest empty folders are pruned first
    folders.sort(key=lambda p: p.count("/"), reverse=True)

    pruned = 0
    for folder in folders:
        contents = asset_lib.list_assets(folder, recursive=False, include_folder=True)
        if len(contents) == 0:
            success = asset_lib.delete_directory(folder)
            if success:
                pruned += 1
                unreal.log(f"[FolderPruner] Deleted empty folder: {folder}")

    unreal.log(f"[FolderPruner] Finished! Pruned {pruned} empty folders.")

if __name__ == "__main__":
    prune_empty_folders("/Game/")
